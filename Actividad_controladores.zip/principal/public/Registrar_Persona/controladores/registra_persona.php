<?php

$nombre = $_POST ["nombre"];
$apellido = $_POST ["apellido"];
$estrato = $_POST ["estrato"];



if (isset($_POST["enviar"])) {
    $miValor = $_POST["mi_valor"];

    if($miValor == 0)
    {
        die("Usted a seleccionado que no desea algun estimulo educativo");
    }
    
}



if($estrato<=3)
{
    print "Aspirante ". $nombre. " ". $apellido. ", Usted ha sido registrado con el estimulo educativo";
}

else
{
    print "Aspirante ". $nombre." ". $apellido. ", Lo sentimos, no hemos podido registrarte con el estimulo 
    educativo debido a que cuentas con un estrato muy alto";
}

?>
<!doctype html>
<html lang="en" data-bs-theme="auto">
  <head><script src="../../../../assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.122.0">
    <title>Registra Persona</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/sign-in/">

    

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">

<link href="../../../../assets/dist/css/bootstrap.min.css" rel="stylesheet">
<center>
    <style>

      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      body { 
        font-family: Arial, Helvetica, sans-serif;
        background-color: #f8f9fa;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      } 



      .form-content {
        background: linear-gradient(
        50deg,
        rgb(255, 255, 255) 30%,
        rgb(255, 255, 255));
        
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        padding: 30px;
        width: 415px;
        border-radius: 10px;
        box-shadow: 0 0 20px rgba(158, 158, 158, 0.493);
      }

      @media (min-width: 76px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgb(0, 0, 0);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(255, 0, 0, 0.1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #5500ff;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }

      .bd-mode-toggle {
        z-index: 1500;
      }

      .bd-mode-toggle .dropdown-menu .active .bi {
        display: block !important;
      }

      .btn-primary-1{
        background-color: rgb(0, 170, 0);
      }

      .btn-1{
        background-color: rgb(0, 170, 0);
        border: 0;
        border-radius: 5px;
      }

      .separator {
      display: flex;
      align-items: center;
      text-align: center;
    }

    .separator::before,
    .separator::after {
      content: '';
      flex: 1;
      border-bottom: 1px solid #ccc;
    }

    .separator::before {
      margin-right: 10px;
    }

    .separator::after {
      margin-left: 10px;
    }

    input , textarea {
    
    background-color: #ffffffce;
    
}
    </style>

    
    <!-- Custom styles for this template -->
    
    
    

    
<main class="form-signin w-100 m-auto">
  <img class="mb-4" src="../img/itfip.jpg" alt="" width="400" height="90">
  <div class="form-content">
  <form method="post" action="../controladores/registra_persona.php">
    
    <font color="black"> <h1 class="h3 mb-3 fw-normal">Ingrese los siguientes datos por favror </h1> </font>

    
      <input type="text" id="inombre" class="form-control" name="nombre" placeholder="Nombre" required> 
      <label for="inombre">  </label>
    
    
      <input type="text" id="iapellido" class="form-control" name="apellido" placeholder="Apellido" required>
      <label for="iapellido"></label>
    
      <input type="number" id="icelular" class="form-control" name="celular" placeholder="Celular">
      <label for="icelular"></label>

      <input type="email" id="iemail" class="form-control" name="email" placeholder="Email">
      <label for="iemail"></label>

      <input type="number" id="iestrato" class="form-control" name="estrato" placeholder="Estrato" min=0 required>
      <label for="iestrato"></label>

      <br>
      <label for="estimulo"> Desea obtener el estimulo educativo?</label> 
      
      <div class="row g-3">
        <div class="col-sm-6">
          <button type="submit" id="estimulo" class="form-control" name="estimulo"> Si </button>
        </div>

        <div class="col-sm-6">
          <input type="hidden" name="mi_valor" value="0">
          <button type="submit" id="estimulo" class="form-control" name="enviar" value="boton1"> No </button>
        </div>
      </div>
    
    </div>
    

     
  </form>
</div>
</main>
<script src="../../../../assets/dist/js/bootstrap.bundle.min.js"></script>

    </body>
  </center>
</html>

<?php

$programa = $_POST ["programa"];
$documento = $_POST ["documento"];


print "Te has matriculado en ". $programa. ". Con su numero de documento ". $documento;

?>
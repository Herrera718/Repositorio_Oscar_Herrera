<?php

$usuario = $_POST ["usuario"];
$contraseña = $_POST ["contraseña"];


if($usuario=="itfip" and $contraseña==2024) 
{
    print "Has iniciado sesion correctamente";
}


else
{
    print "Inicio de sesion incorrecto";
}

?>